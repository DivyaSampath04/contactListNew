import React, {Component} from 'react';
import './Toolbar.css';
import ViewContacts from '../../components/ViewContacts/ViewContacts';
import '../../components/ViewContacts/ViewContacts.css';
//import Aux from '../../hoc/Aux';
class Toolbar extends Component {
    state = {
        value : "Mark Henry",
        isAdd : false,
        conValue : "",
        addMore : false,
        newConValue : "",
        search : false,
        searchtext : ""
    }

    addContact = () =>{
        this.setState({isAdd : true});
       // console.log(this.state.isAdd);
    }
    addMoreContact = () => {
        this.setState({addMore: true});

    }
    selectedContact = (event) =>{
       // console.log(event.target.value);
        this.setState({value : event.target.value});
        console.log(this.state.value);
        
    }
    hideAdd = () =>{
        this.setState({isAdd : false});
    }
    hideAddNew = () =>{
        this.setState({addMore: false});
    }
    changeHandler = (event) => {
        //console.log(event.target.value);
       this.setState({conValue : event.target.value });
       
    }
    changeHandlerForMoreContacts = (event) => {
        //console.log(event.target.value);
       this.setState({newConValue : event.target.value });
       
    }
    searchHandler = (event) =>{
        this.setState({search: false});
        this.setState({searchtext : event.target.value})


    }
    render(){
    
    return(
       <div>
        <div className = "Toolbar">
                <p className = "Text">CONTACT LIST</p>
                <button className = "Button" onClick = {this.addContact}>Add</button>
                
                <div>
                
                {this.state.isAdd === true ?
                <div className = "AddContact">
                    <input type = "text" placeholder = "Enter contact name"  onChange = {this.changeHandler}/>
                    <button type = "submit" >Add</button>
                    <button type = "submit" onClick = {this.hideAdd}>Close</button>
                </div> : null }
               
               
            </div>
            
                <select className = "Button" value ={this.state.value} onChange = {this.selectedContact} >
                    <option value = "Mark Henry">Mark</option>
                    <option value = "John Messy">John</option>
                    <option value = "Peter Harry">Peter</option>
                    <option>{this.state.conValue}</option>
                </select>

        
        </div>
       
        <div>
            <input className = "SearchBar" type = "text" onChange = {this.searchHandler} placeholder = "Search contact name" />  
            <button className = "NewButton" onClick = {this.addMoreContact}>ADD CONTACTS</button>
            <div>
            {this.state.addMore === true ?
                <div className = "AddContact">
                    <input placeholder = "Enter contact name" 
                    type = "text" onChange = {this.changeHandlerForMoreContacts} />
                    <button type = "submit" onClick = {this.hideAddNew}>Close</button>
                </div> : null }
                </div>
        </div>
        <div>
            <ViewContacts selectedName = {this.state.value} newConVal = {this.state.newConValue}/>
        </div>
      

    </div>
    );
}

}
export default Toolbar;