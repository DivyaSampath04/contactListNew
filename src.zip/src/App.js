import React, { Component } from 'react';
//import logo from './logo.svg';
//import './App.css';
import Builder from './containers/Builder/Builder';
import Aux from './hoc/Aux';

class App extends Component{

  render(){
  return (
    <Aux>
      <Builder />
    </Aux>
  );
  }
}

export default App;
